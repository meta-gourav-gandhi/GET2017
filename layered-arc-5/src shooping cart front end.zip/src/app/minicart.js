"use strict";
var MiniCart = (function () {
    function MiniCart() {
    }
    return MiniCart;
}());
exports.MiniCart = MiniCart;
//# sourceMappingURL=minicart.js.map