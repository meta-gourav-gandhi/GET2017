import { Product } from './product';

export class OrderProduct {
    
    total : number;
    products : Product [];


}