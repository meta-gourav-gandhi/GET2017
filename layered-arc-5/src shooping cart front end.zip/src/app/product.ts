export class Product{
    id:number;
    name:string;
    price:number;
    seller : string;
    img_url : string;
  }