export class Order_Payement{
    orderId: number;
    userId : number;
    total : number;
    date : Date;
    cardNumber : string;
    expMonth : number;
    expYear : number;
    cvCode : number;
}