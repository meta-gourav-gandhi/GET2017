import { User } from './user';

export class MiniCart{
    user : User;
    totalNoproduct :number;
    totalCost :number;
}