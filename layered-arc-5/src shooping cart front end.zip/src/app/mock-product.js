"use strict";
exports.products = [
    { id: 11, name: 'Tv', price: 80000 },
    { id: 12, name: 'Mobile', price: 7000 },
    { id: 13, name: 'Washing machine', price: 10000 },
    { id: 14, name: 'Camera', price: 40000 },
    { id: 15, name: 'Speaker', price: 2000 },
    { id: 16, name: 'Jeans', price: 1000 },
    { id: 17, name: 'Shirts', price: 500 },
    { id: 18, name: 'Shoes', price: 899 }
];
//# sourceMappingURL=mock-product.js.map