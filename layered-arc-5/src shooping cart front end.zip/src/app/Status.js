"use strict";
var Status;
(function (Status) {
    Status[Status["Success"] = 0] = "Success";
    Status[Status["FALIURE"] = 1] = "FALIURE";
})(Status = exports.Status || (exports.Status = {}));
;
//# sourceMappingURL=Status.js.map