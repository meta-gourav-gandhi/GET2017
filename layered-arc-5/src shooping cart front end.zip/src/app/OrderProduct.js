"use strict";
var OrderProduct = (function () {
    function OrderProduct() {
    }
    return OrderProduct;
}());
exports.OrderProduct = OrderProduct;
//# sourceMappingURL=OrderProduct.js.map