"use strict";
var Order_Payement = (function () {
    function Order_Payement() {
    }
    return Order_Payement;
}());
exports.Order_Payement = Order_Payement;
//# sourceMappingURL=order_payement.js.map