package com.metacube.shoppingcart.dao.cart;

import com.metacube.shoppingcart.dao.AbstractDao;
import com.metacube.shoppingcart.modal.Cart;

public interface CartDao extends AbstractDao<Cart, Integer> {

}
