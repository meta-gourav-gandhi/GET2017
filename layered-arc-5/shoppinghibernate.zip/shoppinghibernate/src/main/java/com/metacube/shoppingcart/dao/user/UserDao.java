package com.metacube.shoppingcart.dao.user;

import com.metacube.shoppingcart.dao.AbstractDao;
import com.metacube.shoppingcart.modal.User;

public interface UserDao extends AbstractDao<User, Integer> {

}
