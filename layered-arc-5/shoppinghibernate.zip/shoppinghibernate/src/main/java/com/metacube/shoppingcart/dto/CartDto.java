package com.metacube.shoppingcart.dto;

public class CartDto {

}
