package com.metacube.shoppingcart.dao.orderproduct;

import com.metacube.shoppingcart.dao.AbstractDao;
import com.metacube.shoppingcart.modal.OrderProduct;

public interface OrderProductDao extends AbstractDao<OrderProduct, Integer> {

}
